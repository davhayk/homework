import java.util.Scanner;

public class Problem4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Type a number: ");
        int num1 = scanner.nextInt();
        System.out.println( num1%2 == 0 );
    }
}
