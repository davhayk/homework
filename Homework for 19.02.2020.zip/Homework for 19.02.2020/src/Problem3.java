import java.util.Scanner;
public class Problem3 {
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
//        double num1 = scan.nextDouble();
//          double num2 = scan.nextDouble();
//          Exception in thread "main" java.util.InputMismatchException Im mot ay senc error a talis.
//        	at java.base/java.util.Scanner.throwFor(Scanner.java:939)
//        	at java.base/java.util.Scanner.next(Scanner.java:1594)
//        	at java.base/java.util.Scanner.nextDouble(Scanner.java:2564)
//        	at Problem3.main(Problem3.java:5)
        double num1 = 0.21, num2 = 0.56;
            System.out.println( num1 >= 0 && num1 <= 1 && num2 >= 0 && num2 <= 1 );
    }
}
