public class Problem11 {
    public static void main(String[] args) {
        // Ahavor zzveli cragir a, dimaceq. Erevi xndri normal chhaskanalus ardyunqn a
        boolean doesSignificantWork = false, makesBreakthrough = true, nobelPrizeCandidate;
                        // Dzer orinakn a -
//        if (doesSignificantWork == true) {
//            if (makesBreakthrough == true)
//                nobelPrizeCandidate = true;
//            else
//                nobelPrizeCandidate = false;
//        } else if ( !doesSignificantWork == true )
//            nobelPrizeCandidate = false;
//        System.out.println( nobelPrizeCandidate );
                       // First part -
//        if ( doesSignificantWork == true && makesBreakthrough == true )
//                nobelPrizeCandidate = true;
//          else
//            nobelPrizeCandidate = false;
//        System.out.println( nobelPrizeCandidate );
                        // Second part -
        System.out.println( "nobelPrizeCandidate = " + ( doesSignificantWork == true && makesBreakthrough == true )  );
    }
}
