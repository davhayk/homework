package com.company;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
        System.out.println("Import the first integer: ");
        int a = scanner.nextInt();
        System.out.println("Import the second integer: ");
        int b = scanner.nextInt();
        System.out.println("Import the third integer: ");
        int c = scanner.nextInt();
        System.out.println("Import the fourth integer: ");
        int d = scanner.nextInt();
        System.out.println( a == b && a == c && a == d);
    }
}
