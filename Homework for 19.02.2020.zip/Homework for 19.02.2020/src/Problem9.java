import java.util.Scanner;

public class Problem9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input x and y: ");
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        if ( ( x > 0 && y > 0 ) || ( x < 0 && y < 0 ) )
            System.out.println("True");
        else if ( ( x > 0 && y < 0 ) || ( x < 0 && y > 0 ) )
            System.out.println("False");
        else
            System.out.println("One number/both is/are equal to 0");
    }
}
