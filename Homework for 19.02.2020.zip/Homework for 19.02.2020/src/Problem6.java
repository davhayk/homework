import java.util.Scanner;

public class Problem6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input seconds: ");
        int seconds = scanner.nextInt();
        int minutes = 0, hours = 0;
        if (seconds >= 60) {
            minutes = seconds / 60;
            seconds = seconds % 60;
            if (minutes >= 60)
                hours = minutes / 60;
            minutes = minutes % 60;
        }
        System.out.println(hours + ":" + minutes + ":" + seconds);
        // Nuyny arandz if-eri.
//        System.out.println(seconds/3600 + ":" + ( seconds - hours*3600 )/60 + ":" + seconds - hours*3600 - minutes*60;);
    }
}
