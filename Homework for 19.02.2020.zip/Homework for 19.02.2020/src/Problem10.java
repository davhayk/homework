import java.util.Scanner;

public class Problem10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input the numbers: ");
        int age1 = scanner.nextInt();
        int age2 = scanner.nextInt();
        int age3 = scanner.nextInt();
        int max = age1, min = age2;
        if ( age1 < age2 ) {
            max = age2;
            min = age1;
        }
        if ( max < age3 )
            max = age3;
        else if ( min > age3 )
            min = age3;
        System.out.println("The oldest one is: " + max);
        System.out.println("The youngest one is: " + min);
    }
}
