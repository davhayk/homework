import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.Locale;
public class Problem12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Scanner scan = new Scanner(System.in).useLocale(Locale.US);
        System.out.println("Input the first number: ");
        double a = scan.nextDouble();
        System.out.println("Input the second number: ");
        double b = scan.nextDouble();
        System.out.println("Input the operator: "); // float-y user input anelu het stex el ka.
        char M = '*';
        double c = 0;
        if ( M == '*' )
            c = a * b;
        else if (M == '/')
            c = a / b;
        else if (M == '+')
            c = a + b;
        else if ( M == '-')
            c = a - b;
        else if ( M == '0')
            System.out.println("Can't divide by zero");
        else
            System.out.println( "You were need to input an operator");
        System.out.println(c);
    }
}
